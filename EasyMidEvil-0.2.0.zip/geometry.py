"""Procedural, exterior-only medieval buildings. No operators or scene changes.

build(params, materials, collection) returns the parent empty. Geometry is batched
by material; windows and doors are decorative facades, not cut-through openings.
"""
import math
import random

import bpy
from mathutils import Vector


def build(params, materials, collection):
    """Append a deterministic building to collection and return its parent empty."""
    style = str(params.get('style', 'COTTAGE')).upper()
    if style not in {'COTTAGE', 'TAVERN', 'TOWER', 'BLACKSMITH', 'KEEP'}:
        raise ValueError('Unknown building style: ' + style)
    w = float(params.get('width', 6.0))
    d = float(params.get('depth', 5.0))
    floors = int(params.get('floors', 1))
    if not math.isfinite(w) or not math.isfinite(d) or w <= 0 or d <= 0:
        raise ValueError('width and depth must be finite and positive')
    if not 1 <= floors <= 3:
        raise ValueError('floors must be between 1 and 3')
    keys = ('plaster', 'timber', 'stone', 'roof', 'metal', 'glass', 'wood', 'accent')
    for key in keys:
        if key not in materials or materials[key] is None:
            raise ValueError('Missing material: ' + key)
    rng = random.Random(params.get('seed', 0))
    detail = bool(params.get('detail', True))
    # Scale all architectural proportions with the smaller footprint to keep
    # generated details sensible even for unusually small or large inputs.
    s = min(w, d) / 5.0
    hfloor = 2.8 * s
    h = hfloor * floors
    batches = {key: ([], []) for key in keys}
    grain_uvs = {'wood': [], 'timber': []}

    def mesh(key, verts, faces, grain_axis=None):
        vs, fs = batches[key]
        start = len(vs)
        vs.extend(verts)
        fs.extend(tuple(start + i for i in f) for f in faces)
        if key in grain_uvs:
            points = [Vector(v) for v in verts]
            if grain_axis is None:
                extents = [max(p[i] for p in points)-min(p[i] for p in points) for i in range(3)]
                axis = Vector(tuple(1.0 if i == max(range(3), key=lambda j: extents[j]) else 0.0 for i in range(3)))
            else:
                axis = Vector(grain_axis).normalized()
            for face in faces:
                normal = (points[face[1]]-points[face[0]]).cross(points[face[2]]-points[face[0]])
                if normal.length < 1e-9:
                    normal = Vector((0, 0, 1))
                else:
                    normal.normalize()
                across = normal.cross(axis)
                if across.length < 1e-6:
                    across = normal.cross(Vector((1, 0, 0)))
                    if across.length < 1e-6:
                        across = normal.cross(Vector((0, 1, 0)))
                    along = normal.cross(across).normalized()
                else:
                    along = axis
                across.normalize()
                grain_uvs[key].extend((points[i].dot(across), points[i].dot(along)) for i in face)

    def box(key, center, size):
        x, y, z = center
        a, b, c = (v / 2 for v in size)
        mesh(key, [(x-a,y-b,z-c),(x+a,y-b,z-c),(x+a,y+b,z-c),(x-a,y+b,z-c),
                   (x-a,y-b,z+c),(x+a,y-b,z+c),(x+a,y+b,z+c),(x-a,y+b,z+c)],
             [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)])

    def beam(key, p, q, thickness):
        p, q = Vector(p), Vector(q)
        axis = q - p
        if axis.length < 1e-8:
            return
        u = axis.normalized().cross(Vector((0, 1, 0)))
        if u.length < 1e-6:
            u = axis.normalized().cross(Vector((1, 0, 0)))
        u.normalize()
        v = axis.normalized().cross(u).normalized()
        u *= thickness / 2
        v *= thickness / 2
        verts = [tuple(t + a*u + b*v) for t in (p,q) for a,b in ((-1,-1),(1,-1),(1,1),(-1,1))]
        mesh(key, verts, [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)], axis)

    if style == 'TOWER':
        # A circular footprint fits inside both requested dimensions.
        radius = min(w,d)/2
        n = 32
        base = 0.25*s
        top = base+h
        def cylinder(key, r, z0, z1):
            verts = [(r*math.cos(2*math.pi*i/n),r*math.sin(2*math.pi*i/n),z)
                     for z in (z0,z1) for i in range(n)]
            faces = [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
            faces += [tuple(reversed(range(n))), tuple(range(n,2*n))]
            mesh(key,verts,faces)
        cylinder('stone',radius+0.13*s,0,base+0.12*s)
        cylinder('stone',radius,base,top)
        cylinder('stone',radius+0.14*s,top-0.22*s,top+0.06*s)
        # Conical roof and finial.
        over = radius+0.34*s
        peak = top+2.15*s
        verts = [(over*math.cos(2*math.pi*i/n),over*math.sin(2*math.pi*i/n),top)
                 for i in range(n)] + [(0,0,peak)]
        mesh('roof',verts,[(i,(i+1)%n,n) for i in range(n)]+[tuple(reversed(range(n)))])
        beam('metal',(0,0,peak),(0,0,peak+0.45*s),0.07*s)
        def radial(angle, u, outward, z):
            return (math.cos(angle)*(radius+outward)-math.sin(angle)*u,
                    math.sin(angle)*(radius+outward)+math.cos(angle)*u,z)
        # Dark arrow slits on each face, framed by radial stone jambs.
        for floor in range(floors):
            for j in range(8):
                if floor == 0 and j == 6:
                    continue
                a = j*math.tau/8
                z = base+floor*hfloor+1.55*s
                center = radial(a,0,0.045*s,z)
                # Narrow rectangle on the tangent plane, slightly outside wall.
                p = [radial(a,u,0.06*s,z+v) for u,v in
                     ((-0.10*s,-0.48*s),(0.10*s,-0.48*s),(0.10*s,0.48*s),(-0.10*s,0.48*s))]
                mesh('metal',p,[(0,1,2,3)])
                for u in (-0.17*s,0.17*s):
                    beam('stone',radial(a,u,0.10*s,z-0.55*s),radial(a,u,0.10*s,z+0.55*s),0.13*s)
                beam('stone',radial(a,-0.17*s,0.1*s,z+0.55*s),radial(a,0.17*s,0.1*s,z+0.55*s),0.13*s)
        # Front arched door: flat inset overlay and a stone voussoir-like arch.
        a = -math.pi/2
        dw = min(0.8*s,radius*0.55)
        spring = base+1.55*s
        door = [radial(a,-dw,0.08*s,base),radial(a,dw,0.08*s,base),radial(a,dw,0.08*s,spring)]
        door += [radial(a,dw*math.cos(t),0.08*s,spring+dw*math.sin(t)) for t in
                 [math.pi*i/8 for i in range(1,9)]]
        mesh('wood',door,[tuple(range(len(door)))])
        for u in (-dw,dw):
            beam('stone',radial(a,u,0.13*s,base),radial(a,u,0.13*s,spring),0.22*s)
        for i in range(8):
            t1,t2 = math.pi*i/8,math.pi*(i+1)/8
            beam('stone',radial(a,dw*math.cos(t1),0.13*s,spring+dw*math.sin(t1)),
                 radial(a,dw*math.cos(t2),0.13*s,spring+dw*math.sin(t2)),0.22*s)
        for z in (base+0.55*s,base+1.2*s):
            beam('metal',radial(a,-dw*0.8,0.17*s,z),radial(a,dw*0.8,0.17*s,z),0.08*s)
        if detail:
            for _ in range(40):
                a = rng.uniform(0,math.tau)
                z = rng.uniform(base+0.2*s,top-0.2*s)
                # Keep scattered masonry clear of slit frames and the doorway.
                nearest_slit = round(a / (math.tau/8)) * (math.tau/8)
                if abs((a-nearest_slit+math.pi) % math.tau-math.pi) * radius < 0.45*s:
                    continue
                if abs((a+math.pi/2+math.pi) % math.tau-math.pi) * radius < dw+0.35*s and z < spring+dw+0.25*s:
                    continue
                u = rng.uniform(0.1,0.24)*s
                beam('stone',radial(a,-u,0.025*s,z),radial(a,u,0.025*s,z),0.09*s)
    else:
        # Foundation and walls: masonry buildings are visually distinct from timber houses.
        masonry = style in {'TOWER', 'KEEP'}
        box('stone', (0,0,0.16*s), (w+0.18*s,d+0.18*s,0.32*s))
        box('stone' if masonry else 'plaster', (0,0,h/2+0.25*s), (w,d,h))
        base = 0.25*s
        top = base+h
        # Wall coordinates: u along the wall, v outward, z vertical.
        def point(side, u, v, z):
            if side == 0: return (u, -d/2-v, z)
            if side == 1: return (u, d/2+v, z)
            if side == 2: return (-w/2-v, u, z)
            return (w/2+v, u, z)

        def wallbox(key, side, u, z, length, height, thick, offset=0.03):
            c = point(side, u, offset*s, z)
            size = (length, thick, height) if side < 2 else (thick, length, height)
            box(key, c, size)

        def wallbeam(side, u1, z1, u2, z2, thick, offset=0.10):
            beam('timber', point(side,u1,offset*s,z1), point(side,u2,offset*s,z2), thick)

        for side in range(4):
            length = w if side < 2 else d
            if not masonry:
                for floor in range(floors + 1):
                    wallbox('timber', side, 0, base+floor*hfloor, length+0.12*s, 0.16*s, 0.16*s)
                for u in (-length/2+0.09*s, length/2-0.09*s):
                    wallbox('timber', side, u, base+h/2, 0.17*s, h, 0.17*s)
            elif detail:
                for floor in range(1, floors):
                    wallbox('stone', side, 0, base+floor*hfloor, length+0.12*s, 0.14*s, 0.17*s)
            # Window arrangement adapts to footprint, with the front door occupying the center.
            count = max(1, min(12, int(length/((2.7 if masonry else 2.1)*s))))
            for floor in range(floors):
                for i in range(count):
                    u = (i-(count-1)/2)*length/count
                    if side == 0 and floor == 0 and abs(u) < (1.65 if style == 'TAVERN' else 1.15)*s:
                        continue
                    if style == 'BLACKSMITH' and side == 3 and abs(u) < 1.5*s:
                        continue
                    showcase = style == 'TAVERN' and side == 0 and floor > 0 and abs(u) < length/count*.61
                    z = base + floor*hfloor + (1.72 if showcase else 1.65)*s
                    ww = min((0.24 if masonry else 1.18 if showcase else 0.78)*s, length/(count+1)*0.65)
                    wh = (1.25 if masonry or showcase else 1.05)*s
                    # Dark reveal and inset glass, with frame and mullions.
                    wallbox('timber' if not masonry else 'stone',side,u,z,ww+0.22*s,wh+0.22*s,0.12*s,0.07)
                    wallbox('glass',side,u,z,ww,wh,0.14*s,0.14)
                    wallbox('timber' if not masonry else 'metal',side,u,z,0.055*s,wh,0.17*s,0.20)
                    wallbox('timber' if not masonry else 'metal',side,u,z,ww,0.055*s,0.17*s,0.20)
                    wallbox('stone' if masonry else 'wood',side,u,z-wh/2-0.12*s,ww+0.35*s,0.12*s,0.30*s,0.13)
                    if showcase:
                        for sign in (-1, 1):
                            wallbox('timber',side,u+sign*ww/4,z,.048*s,wh,.17*s,.20)
                        wallbox('wood',side,u,z+wh/2+.11*s,ww+.34*s,.13*s,.28*s,.14)
                    elif detail and not masonry:
                        for sign in (-1,1):
                            wallbox('wood',side,u+sign*(ww/2+0.16*s),z,0.22*s,wh,0.12*s,0.10)
                if not masonry:
                    # Structural bay posts divide long walls without crossing openings.
                    for i in range(1, count):
                        u = -length/2 + i*length/count
                        if side == 0 and floor == 0 and abs(u) < 0.8*s:
                            continue
                        wallbox('timber', side, u, base+(floor+0.5)*hfloor, 0.13*s, hfloor-0.16*s, 0.16*s, 0.08)
                if detail and not masonry:
                    # Diagonal braces stay at the corners, clear of the central openings.
                    for sign in (-1,1):
                        wallbeam(side,sign*(length/2-0.12*s),base+floor*hfloor+0.22*s,
                                 sign*(length/2-min(0.45*s,length*0.1)),base+floor*hfloor+0.9*s,0.11*s)

        # Front door: layered timber surround, planks, iron straps, and handle.
        doorw = min(1.1*s, w*0.3)
        doorh = 2.05*s
        wallbox('stone' if masonry else 'timber',0,0,base+doorh/2,doorw+0.28*s,doorh+0.20*s,0.20*s,0.08)
        wallbox('wood',0,0,base+doorh/2,doorw,doorh,0.22*s,0.18)
        for i in range(1,4):
            wallbox('timber',0,-doorw/2+i*doorw/4,base+doorh/2,0.025*s,doorh,0.23*s,0.21)
        for z in (0.48,1.55):
            wallbox('metal',0,0,base+z*s,doorw*0.85,0.07*s,0.25*s,0.23)
        wallbox('metal',0,doorw*0.3,base+0.95*s,0.09*s,0.12*s,0.28*s,0.25)
        box('stone',(0,-d/2-0.34*s,0.12*s),(doorw+0.5*s,0.7*s,0.24*s))

        if style == 'KEEP':
            # Broad corner buttresses and a projecting machicolation-like cornice.
            for x in (-w/2, w/2):
                for y in (-d/2, d/2):
                    box('stone', (x,y,base+h*0.48), (0.65*s,0.65*s,h*0.96))
                    box('stone', (x,y,base+0.45*s), (0.9*s,0.9*s,0.9*s))
            for side in range(4):
                length = w if side < 2 else d
                wallbox('stone',side,0,top-0.28*s,length+0.8*s,0.3*s,0.65*s,0.15)
                for i in range(max(2,min(10,int(length/s)))):
                    u = -length/2+(i+0.5)*length/max(2,min(10,int(length/s)))
                    wallbox('stone',side,u,top-0.55*s,0.26*s,0.4*s,0.45*s,0.12)
            # Flat parapet with alternating merlons around the entire roof.
            box('stone',(0,0,top+0.12*s),(w+0.3*s,d+0.3*s,0.24*s))
            for side in range(4):
                length = w if side < 2 else d
                n = max(2,min(12,int(length/(0.7*s))))
                for i in range(n):
                    u = -length/2+(i+0.5)*length/n
                    wallbox('stone',side,u,top+0.48*s,length/n*0.57,0.65*s,0.38*s,0.04)
        elif style == 'TOWER':
            # Steep pyramidal roof over a square or rectangular tower.
            over = 0.32*s
            ridge = top + 2.0*s
            mesh('roof',[(-w/2-over,-d/2-over,top),(w/2+over,-d/2-over,top),
                         (w/2+over,d/2+over,top),(-w/2-over,d/2+over,top),(0,0,ridge)],
                 [(0,1,4),(1,2,4),(2,3,4),(3,0,4),(3,2,1,0)])
            beam('metal',(0,0,ridge),(0,0,ridge+0.45*s),0.07*s)
        else:
            # Ridge follows the long footprint axis: even a very wide building
            # gets a properly pitched roof rather than a shallow, stretched gable.
            over = 0.35*s
            long_x = w > d
            span = d if long_x else w
            run = w if long_x else d
            rise = min(2.4*s, span*0.42)
            def roofpoint(across, along, z):
                return (along, across, z) if long_x else (across, along, z)
            def rp(a, b, z):
                return roofpoint(a, b, z)
            for along, reverse in ((-run/2, False), (run/2, True)):
                mesh('plaster', [rp(-span/2,along,top), rp(span/2,along,top),
                                 rp(0,along,top+rise)], [(2,1,0) if reverse else (0,1,2)])
                if detail:
                    # Exposed gable framing gives the otherwise blank end walls character.
                    face = along + (0.04*s if reverse else -0.04*s)
                    beam('timber',rp(0,face,top+0.08*s),rp(0,face,top+rise-0.08*s),0.12*s)
                    beam('timber',rp(-span*0.27,face,top+rise*0.42),
                         rp(span*0.27,face,top+rise*0.42),0.11*s)
            mesh('roof', [rp(-span/2-over,-run/2-over,top), rp(0,-run/2-over,top+rise),
                          rp(span/2+over,-run/2-over,top), rp(-span/2-over,run/2+over,top),
                          rp(0,run/2+over,top+rise), rp(span/2+over,run/2+over,top)],
                 [(0,3,4,1),(1,4,5,2)] if long_x else [(1,4,3,0),(2,5,4,1)])
            for along in (-run/2-over,run/2+over):
                beam('timber',rp(-span/2-over,along,top),rp(0,along,top+rise),0.15*s)
                beam('timber',rp(0,along,top+rise),rp(span/2+over,along,top),0.15*s)
            beam('timber',rp(0,-run/2-over,top+rise),rp(0,run/2+over,top+rise),0.13*s)
            # Exposed rafter tails articulate the eaves at regular intervals.
            if detail:
                rafters = max(2, min(16, int(run/(1.1*s))))
                for i in range(rafters+1):
                    along = -run/2 + run*i/rafters
                    for sign in (-1,1):
                        beam('timber',rp(sign*(span/2-0.25*s),along,top+rise*0.12),
                             rp(sign*(span/2+over),along,top-0.08*s),0.11*s)
            # Repeated small gabled dormers break up very long roof slopes.
            if detail and long_x and w > 2*d:
                n = min(4, max(2, int(w/(5*s))))
                for i in range(n):
                    x = (i-(n-1)/2)*w/n
                    half = min(0.68*s, w/n*0.25)
                    front = -d/2-0.04*s
                    back = -d/2+0.75*s
                    eave = top+0.65*s
                    peak = top+1.22*s
                    mesh('plaster', [(x-half,front,top), (x+half,front,top),
                                     (x+half,front,eave), (x,front,peak), (x-half,front,eave)],
                         [(0,1,2,3,4)])
                    mesh('roof', [(x-half-0.08*s,front-0.10*s,eave), (x,front-0.10*s,peak),
                                  (x+half+0.08*s,front-0.10*s,eave),
                                  (x-half-0.08*s,back,eave), (x,back,peak), (x+half+0.08*s,back,eave)],
                         [(1,4,3,0),(2,5,4,1)])
                    beam('timber',(x-half,front-0.12*s,eave),(x,front-0.12*s,peak),0.10*s)
                    beam('timber',(x,front-0.12*s,peak),(x+half,front-0.12*s,eave),0.10*s)
                    wallbox('timber',0,x,top+0.33*s,0.55*s,0.55*s,0.14*s,0.12)
                    wallbox('glass',0,x,top+0.33*s,0.42*s,0.42*s,0.16*s,0.20)
                    wallbox('timber',0,x,top+0.33*s,0.04*s,0.42*s,0.18*s,0.27)
            # Chimney above one roof slope, varied deterministically by seed.
            cx = rng.choice((-1,1))*w*0.27

            cy = rng.uniform(-0.2,0.25)*d
            ch = top+rise+0.35*s
            box('stone',(cx,cy,(top+ch)/2),(0.65*s,0.65*s,ch-top+0.7*s))
            box('stone',(cx,cy,ch+0.38*s),(0.83*s,0.83*s,0.16*s))

        if style == 'TAVERN':
            # Deep gabled porch with a tankard sign and cross-braced posts.
            eave = base + 2.37*s
            peak = eave + .51*s
            half = min(w*.32, 1.43*s)
            front, back = -d/2-1.17*s, -d/2+.04*s
            for y in (front, back):
                for sign in (-1, 1):
                    beam('timber',(sign*half,y,eave),(0,y,peak),.13*s)
            mesh('roof',[(-half,front,eave),(0,front,peak),(half,front,eave),
                         (-half,back,eave),(0,back,peak),(half,back,eave)],
                 [(1,4,3,0),(2,5,4,1)])
            beam('timber',(-half,front,eave),(half,front,eave),.16*s)
            beam('timber',(0,front,peak),(0,back,peak),.12*s)
            for sign in (-1, 1):
                x = sign*(half-.14*s)
                box('stone',(x,front+.15*s,.17*s),(.36*s,.36*s,.34*s))
                beam('timber',(x,front+.15*s,.25*s),(x,front+.15*s,eave),.18*s)
                beam('timber',(x,front+.15*s,eave-.46*s),(x-sign*.41*s,front+.1*s,eave-.055*s),.11*s)
                beam('timber',(x,front+.15*s,eave-.46*s),(x,front+.53*s,eave-.06*s),.11*s)
            if detail:
                y, z = front-.075*s, eave-.23*s
                box('timber',(0,y,z),(1.16*s,.12*s,.39*s))
                box('accent',(0,y-.07*s,z),(1.02*s,.041*s,.27*s))
                box('wood',(-.025*s,y-.105*s,z),(.15*s,.033*s,.15*s))
                for dz in (-.06,.06):
                    box('wood',(.076*s,y-.105*s,z+dz*s),(.076*s,.03*s,.025*s))
                box('wood',(.105*s,y-.105*s,z),(.024*s,.03*s,.13*s))
        elif style == 'BLACKSMITH':
            # Tall exterior chimney projects past the main roof and anchors the forge.
            chimney_x = w/2+0.50*s
            chimney_top = top+1.4*s
            box('stone',(chimney_x,0,(base+chimney_top)/2),
                (1.05*s,1.25*s,chimney_top-base))
            box('stone',(chimney_x,0,chimney_top),(1.35*s,1.55*s,0.25*s))
            box('metal',(chimney_x,-0.64*s,1.1*s),(0.75*s,0.10*s,0.85*s))
            x = w/2+0.65*s
            box('stone',(x,0,0.55*s),(1.2*s,1.6*s,1.1*s))
            box('metal',(x,-0.05*s,1.16*s),(0.8*s,1.0*s,0.16*s))
            box('accent',(x,-0.05*s,1.26*s),(0.45*s,0.55*s,0.06*s))
            for y in (-1.0*s,1.0*s):
                beam('timber',(w/2+1.4*s,y,0.25*s),(w/2+1.4*s,y,2.0*s),0.16*s)
            mesh('roof',[(w/2,-1.2*s,2.55*s),(w/2,1.2*s,2.55*s),
                         (w/2+1.55*s,1.2*s,2.0*s),(w/2+1.55*s,-1.2*s,2.0*s)],[(3,2,1,0)])
            # Workbench and anvil on the open outer edge of the lean-to.
            ax, ay = w/2+1.8*s, -1.35*s
            box('wood',(ax,ay,0.36*s),(0.65*s,0.65*s,0.72*s))
            box('metal',(ax,ay,0.78*s),(0.85*s,0.43*s,0.18*s))
            box('metal',(ax+0.32*s,ay,0.89*s),(0.25*s,0.28*s,0.10*s))
            box('wood',(w/2+1.9*s,0.8*s,0.7*s),(1.0*s,0.55*s,0.15*s))
            for y in (0.58*s,1.02*s):
                beam('timber',(w/2+1.9*s,y,0.1*s),(w/2+1.9*s,y,0.7*s),0.12*s)

        if detail:
            for side in range(4):
                length = w if side < 2 else d
                for _ in range(min(18, max(3, int(length/s)*2))):
                    u = rng.uniform(-0.46,0.46)*length
                    if side == 0 and abs(u) < 0.8*s:
                        continue
                    # Weathering is confined below the windows, not over their frames.
                    z = base + rng.uniform(0.08,0.60)*s
                    wallbox('stone',side,u,z,rng.uniform(0.18,0.42)*s,0.12*s,0.08*s,0.03)

    root = bpy.data.objects.new('EasyMidEvil_' + style.title(), None)
    collection.objects.link(root)
    for key in keys:
        verts, faces = batches[key]
        if not verts:
            continue
        data = bpy.data.meshes.new('EasyMidEvil_' + key)
        data.from_pydata(verts, [], faces)
        data.update()
        if key in grain_uvs:
            layer = data.uv_layers.new(name='EasyMidEvil_Grain')
            for entry, uv in zip(layer.data, grain_uvs[key]):
                entry.uv = uv
        data.materials.append(materials[key])
        obj = bpy.data.objects.new('EasyMidEvil_' + key, data)
        collection.objects.link(obj)
        obj.parent = root
    return root
