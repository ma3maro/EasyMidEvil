"""Live generation for newly created building roots; unrelated objects are untouched."""
import bpy
import hashlib
from array import array
from . import geometry, materials

PART = '_easymid_generated_part'
SIGNATURE = '_easymid_signature'
LIVE = '_easymid_live'
_BUSY = set()


def _signature(obj):
    h = hashlib.blake2b(digest_size=16)
    mesh = obj.data
    h.update(repr((obj.type, tuple(round(x, 7) for row in obj.matrix_basis for x in row),
                   tuple(m.name if m else '' for m in mesh.materials),
                   len(mesh.vertices), len(mesh.edges), len(mesh.loops), len(mesh.polygons),
                   tuple(m.name for m in obj.modifiers), tuple(c.name for c in obj.constraints),
                   bool(obj.animation_data), bool(mesh.shape_keys), bool(obj.children),
                   obj.hide_viewport, obj.hide_render,
                   tuple(sorted(k for k in obj.keys() if k not in {PART, SIGNATURE})),
                   tuple(sorted(c.name for c in obj.users_collection)))).encode())
    for collection, prop, stride, code in ((mesh.vertices, 'co', 3, 'f'),
                                            (mesh.loops, 'vertex_index', 1, 'i'),
                                            (mesh.polygons, 'loop_total', 1, 'i')):
        values = array(code, [0]) * (len(collection) * stride)
        collection.foreach_get(prop, values)
        h.update(values.tobytes())
    for uv in mesh.uv_layers:
        h.update(uv.name.encode())
        values = array('f', [0]) * (len(uv.data) * 2)
        uv.data.foreach_get('uv', values)
        h.update(values.tobytes())
    return h.hexdigest()


def mark_parts(root):
    for obj in root.children:
        if obj.type == 'MESH':
            obj[PART] = True
            obj[SIGNATURE] = _signature(obj)


def _discard_collection(collection):
    for obj in list(collection.objects):
        data = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        if data and isinstance(data, bpy.types.Mesh) and data.users == 0:
            bpy.data.meshes.remove(data)
    bpy.data.collections.remove(collection)


def _archive(scene, parts):
    collection = bpy.data.collections.new('EasyMidEvil | Preserved edits')
    scene.collection.children.link(collection)
    collection.hide_viewport = True
    collection.hide_render = True
    for obj in parts:
        # Keep the original ID and its dependencies, not a duplicate that breaks
        # constraints or links pointing at the original object.
        owners = list(obj.users_collection)
        collection.objects.link(obj)
        for owner in owners:
            owner.objects.unlink(obj)
        obj[PART] = False
        obj.name = 'Preserved | ' + obj.name


def rebuild(root, context):
    """Build first, then swap only owned parts; edited old parts are archived."""
    if not root or not root.get(LIVE) or root.as_pointer() in _BUSY:
        return
    if not context or not context.scene or context.mode != 'OBJECT' or not root.is_editable or not root.users_collection:
        return
    key = root.as_pointer()
    _BUSY.add(key)
    staged = None
    try:
        s = root.easymidevil
        params = dict(style=s.style, width=s.width, depth=s.depth, floors=s.floors, seed=s.seed, detail=s.detail)
        old_parts = [o for o in root.children if o.get(PART) and o.type == 'MESH']
        staged = bpy.data.collections.new('EasyMidEvil | Temporary Build')
        context.scene.collection.children.link(staged)
        new_root = geometry.build(params, materials.create_materials(root.get('_easymid_palette_seed', s.seed)), staged)
        new_parts = list(new_root.children)
        preserve = any(not o.get(SIGNATURE) or _signature(o) != o.get(SIGNATURE) for o in old_parts)
        focus_root = context.view_layer.objects.active in old_parts
        target = root.users_collection[0]
        for obj in new_parts:
            target.objects.link(obj)
            obj.parent = root
            obj[PART] = True
            obj[SIGNATURE] = _signature(obj)
        if focus_root:
            context.view_layer.objects.active.select_set(False)
            root.select_set(True)
            context.view_layer.objects.active = root
        if preserve:
            _archive(context.scene, old_parts)
        else:
            for obj in old_parts:
                data = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if data.users == 0:
                    bpy.data.meshes.remove(data)
        for obj in new_parts:
            staged.objects.unlink(obj)
            obj[SIGNATURE] = _signature(obj)
        bpy.data.objects.remove(new_root, do_unlink=True)
        bpy.data.collections.remove(staged)
        staged = None
        root['building_type'] = s.style
        root['variation'] = s.seed
        root['_easymid_error'] = ''
    except Exception as exc:
        if staged and staged.name in bpy.data.collections:
            _discard_collection(staged)
        root['_easymid_error'] = str(exc)
        print('EasyMidEvil live update failed:', exc)
    finally:
        _BUSY.discard(key)
