"""Procedural medieval materials. Coordinates are local; wood grain follows each piece."""
import random
import bpy

_TAG = 'EasyMidEvil.procedural'


def _version(role):
    # Never mutate older palettes already assigned to a user's objects.
    return 3 if role == 'stone' else 2 if role in {'roof', 'glass', 'wood', 'timber'} else 1
_PALETTE = {
    'plaster': ((.32,.25,.16),(.69,.59,.42),(.86,.78,.60),(.72,.94)),
    'timber': ((.055,.025,.012),(.19,.083,.031),(.34,.18,.075),(.58,.83)),
    'wood': ((.12,.051,.020),(.34,.17,.065),(.53,.32,.14),(.48,.72)),
    'stone': ((.16,.16,.14),(.36,.35,.30),(.55,.52,.43),(.70,.92)),
    'roof': ((.12,.035,.025),(.30,.085,.050),(.48,.19,.10),(.65,.88)),
    'metal': ((.055,.06,.055),(.17,.18,.16),(.30,.29,.24),(.38,.68)),
    'glass': ((.025,.035,.045),(.065,.085,.105),(.12,.15,.18),(.18,.3)),
    'accent': ((.12,.025,.020),(.34,.055,.035),(.57,.15,.075),(.48,.72)),
}


def _build(role, seed):
    mat = bpy.data.materials.new('EasyMidEvil | %s | %s' % (role.title(), seed))
    mat[_TAG] = _version(role)
    mat['EasyMidEvil.role'] = role
    mat['EasyMidEvil.seed'] = str(seed)
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    nodes.clear()

    def node(kind, label, x, y):
        n = nodes.new(kind)
        n.label = label
        n.location = x, y
        return n

    def ramp(source, stops, label, x, y):
        n = node('ShaderNodeValToRGB', label, x, y)
        for element, (position, color) in zip(n.color_ramp.elements, (stops[0], stops[-1])):
            element.position = position
            element.color = (*color, 1)
        for position, color in stops[1:-1]:
            n.color_ramp.elements.new(position).color = (*color, 1)
        links.new(source, n.inputs['Fac'])
        return n.outputs['Color']

    output = node('ShaderNodeOutputMaterial', 'Surface', 1000, 100)
    shader = node('ShaderNodeBsdfPrincipled', 'Medieval surface', 740, 100)
    links.new(shader.outputs['BSDF'], output.inputs['Surface'])
    coords = node('ShaderNodeTexCoord', 'Local coordinates', -1100, 100)
    mapping = node('ShaderNodeMapping', 'Seeded offset', -900, 100)
    rng = random.Random('EasyMidEvil:%s:%s' % (seed, role))
    mapping.inputs['Location'].default_value = [rng.uniform(-100, 100) for _ in range(3)]
    links.new(coords.outputs['Object'], mapping.inputs['Vector'])
    noise = node('ShaderNodeTexNoise', 'Weathering', -660, 250)
    noise.inputs['Scale'].default_value = 3.8
    noise.inputs['Detail'].default_value = 4
    noise.inputs['Roughness'].default_value = .72
    links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
    fine = node('ShaderNodeTexNoise', 'Fine surface grain', -660, -300)
    fine.inputs['Scale'].default_value = 95
    fine.inputs['Detail'].default_value = 3
    links.new(mapping.outputs['Vector'], fine.inputs['Vector'])
    dark, mid, light, (lo, hi) = _PALETTE[role]
    color_source, height = noise.outputs['Fac'], fine.outputs['Fac']
    if role in {'timber', 'wood'}:
        stretch = node('ShaderNodeVectorMath', 'Longitudinal grain', -900, -490)
        stretch.operation = 'MULTIPLY'
        stretch.inputs[1].default_value = (7, .38, 7)
        grain_uv = node('ShaderNodeUVMap', 'Per-beam grain direction', -1100, -490)
        grain_uv.uv_map = 'EasyMidEvil_Grain'
        links.new(grain_uv.outputs['UV'], stretch.inputs[0])
        grain = node('ShaderNodeTexNoise', 'Wood fibers', -660, -550)
        grain.inputs['Scale'].default_value = 2.8
        grain.inputs['Detail'].default_value = 3
        links.new(stretch.outputs['Vector'], grain.inputs['Vector'])
        color_source = height = grain.outputs['Fac']
    elif role == 'stone':
        # Brick Texture uses its input XY plane. Select YZ, XZ or XY by
        # dominant object-space surface normal; Z is always up on walls.
        # Hard selection avoids doubled, translucent joints on curved walls.
        sep = node('ShaderNodeSeparateXYZ', 'Local position', -900, -760)
        links.new(mapping.outputs['Vector'], sep.inputs[0])
        geometry = node('ShaderNodeNewGeometry', 'Surface orientation', -1100, -1050)
        normal = node('ShaderNodeVectorTransform', 'Normal to object space', -900, -1050)
        normal.vector_type = 'NORMAL'
        normal.convert_from = 'WORLD'
        normal.convert_to = 'OBJECT'
        links.new(geometry.outputs['Normal'], normal.inputs['Vector'])
        absolute = node('ShaderNodeVectorMath', 'Absolute normal', -700, -1050)
        absolute.operation = 'ABSOLUTE'
        links.new(normal.outputs['Vector'], absolute.inputs[0])
        axes = node('ShaderNodeSeparateXYZ', 'Normal axes', -500, -1050)
        links.new(absolute.outputs['Vector'], axes.inputs[0])

        def greater(a, b, label, x, y):
            n = node('ShaderNodeMath', label, x, y)
            n.operation = 'GREATER_THAN'
            links.new(a, n.inputs[0])
            links.new(b, n.inputs[1])
            return n.outputs[0]

        x_dominant = greater(axes.outputs['X'], axes.outputs['Y'], 'X over Y', -300, -1050)
        max_xy = node('ShaderNodeMath', 'Largest horizontal normal', -300, -1200)
        max_xy.operation = 'MAXIMUM'
        links.new(axes.outputs['X'], max_xy.inputs[0])
        links.new(axes.outputs['Y'], max_xy.inputs[1])
        top = greater(axes.outputs['Z'], max_xy.outputs[0], 'Horizontal surface', -100, -1200)

        def projection(horizontal, vertical, label, y):
            vector = node('ShaderNodeCombineXYZ', label + ' coordinates', -650, y)
            links.new(horizontal, vector.inputs['X'])
            links.new(vertical, vector.inputs['Y'])
            brick = node('ShaderNodeTexBrick', label, -430, y)
            brick.inputs['Color1'].default_value = (*mid, 1)
            brick.inputs['Color2'].default_value = (*light, 1)
            brick.inputs['Mortar'].default_value = (*dark, 1)
            brick.inputs['Scale'].default_value = 1.0
            brick.inputs['Mortar Size'].default_value = .014
            brick.inputs['Mortar Smooth'].default_value = .02
            brick.inputs['Brick Width'].default_value = .7
            brick.inputs['Row Height'].default_value = .35
            links.new(vector.outputs[0], brick.inputs['Vector'])
            return brick

        wall_x = projection(sep.outputs['Y'], sep.outputs['Z'], 'X-facing masonry', -400)
        wall_y = projection(sep.outputs['X'], sep.outputs['Z'], 'Y-facing masonry', -650)
        cap = projection(sep.outputs['X'], sep.outputs['Y'], 'Horizontal masonry', -900)

        def select(factor, a, b, label, y):
            n = node('ShaderNodeMixRGB', label, -160, y)
            links.new(factor, n.inputs[0])
            links.new(a, n.inputs[1])
            links.new(b, n.inputs[2])
            return n.outputs[0]

        walls = select(x_dominant, wall_y.outputs['Color'], wall_x.outputs['Color'], 'Wall color selection', -400)
        color_source = select(top, walls, cap.outputs['Color'], 'Masonry color selection', -600)
        wall_joints = select(x_dominant, wall_y.outputs['Fac'], wall_x.outputs['Fac'], 'Wall joint selection', -800)
        joints = select(top, wall_joints, cap.outputs['Fac'], 'Masonry joint selection', -1000)
        invert = node('ShaderNodeMath', 'Recessed mortar', 50, -900)
        invert.operation = 'SUBTRACT'
        invert.inputs[0].default_value = 1
        links.new(joints, invert.inputs[1])
        height = invert.outputs[0]
    elif role == 'roof':
        # Project onto the slope: horizontal tangent follows the eaves and
        # the perpendicular tangent follows the pitch, in object-space units.
        geom = node('ShaderNodeNewGeometry', 'Roof orientation', -1100, -800)
        normal = node('ShaderNodeVectorTransform', 'Roof normal in object space', -900, -800)
        normal.vector_type = 'NORMAL'
        normal.convert_from = 'WORLD'
        normal.convert_to = 'OBJECT'
        links.new(geom.outputs['Normal'], normal.inputs['Vector'])
        axes = node('ShaderNodeSeparateXYZ', 'Roof normal components', -700, -800)
        links.new(normal.outputs['Vector'], axes.inputs[0])
        tangent = node('ShaderNodeCombineXYZ', 'Eave direction', -500, -900)
        links.new(axes.outputs['Y'], tangent.inputs['X'])
        neg = node('ShaderNodeMath', 'Negative X normal', -700, -1050)
        neg.operation = 'MULTIPLY'
        neg.inputs[1].default_value = -1
        links.new(axes.outputs['X'], neg.inputs[0])
        links.new(neg.outputs[0], tangent.inputs['Y'])
        length = node('ShaderNodeVectorMath', 'Pitch magnitude', -300, -1100)
        length.operation = 'LENGTH'
        links.new(tangent.outputs[0], length.inputs[0])
        flat = node('ShaderNodeMath', 'Flat roof fallback', -100, -1100)
        flat.operation = 'LESS_THAN'
        flat.inputs[1].default_value = .001
        links.new(length.outputs['Value'], flat.inputs[0])
        fallback = node('ShaderNodeVectorMath', 'Stable eave direction', 100, -1000)
        fallback.operation = 'ADD'
        links.new(tangent.outputs[0], fallback.inputs[0])
        flat_vector = node('ShaderNodeCombineXYZ', 'Flat direction', -100, -1250)
        links.new(flat.outputs[0], flat_vector.inputs['X'])
        links.new(flat_vector.outputs[0], fallback.inputs[1])
        unit = node('ShaderNodeVectorMath', 'Unit eave direction', 300, -1000)
        unit.operation = 'NORMALIZE'
        links.new(fallback.outputs[0], unit.inputs[0])
        pitch = node('ShaderNodeVectorMath', 'Slope direction', 300, -1200)
        pitch.operation = 'CROSS_PRODUCT'
        links.new(normal.outputs['Vector'], pitch.inputs[0])
        links.new(unit.outputs[0], pitch.inputs[1])
        def dot(direction, label, y):
            n = node('ShaderNodeVectorMath', label, 300, y)
            n.operation = 'DOT_PRODUCT'
            links.new(mapping.outputs['Vector'], n.inputs[0])
            links.new(direction, n.inputs[1])
            return n.outputs['Value']
        projection = node('ShaderNodeCombineXYZ', 'Slope coordinates', 500, -650)
        links.new(dot(unit.outputs[0], 'Along eaves', -650), projection.inputs['X'])
        links.new(dot(pitch.outputs[0], 'Along slope', -800), projection.inputs['Y'])
        brick = node('ShaderNodeTexBrick', 'Tile courses', -100, -560)
        brick.inputs['Color1'].default_value = (*mid, 1)
        brick.inputs['Color2'].default_value = (*light, 1)
        brick.inputs['Mortar'].default_value = (*dark, 1)
        brick.inputs['Scale'].default_value = 1.0
        brick.inputs['Mortar Size'].default_value = .008
        brick.inputs['Mortar Smooth'].default_value = .02
        brick.inputs['Brick Width'].default_value = .34
        brick.inputs['Row Height'].default_value = .20
        links.new(projection.outputs[0], brick.inputs['Vector'])
        color_source = brick.outputs['Color']
        invert = node('ShaderNodeMath', 'Recessed tile joints', 100, -560)
        invert.operation = 'SUBTRACT'
        invert.inputs[0].default_value = 1
        links.new(brick.outputs['Fac'], invert.inputs[1])
        height = invert.outputs[0]
    if role in {'stone', 'roof'}:
        mix = node('ShaderNodeMixRGB', 'Weathered masonry', 0, 300)
        mix.blend_type = 'MULTIPLY'
        mix.inputs[0].default_value = .35
        links.new(color_source, mix.inputs[1])
        links.new(noise.outputs['Color'], mix.inputs[2])
        color = mix.outputs['Color']
    else:
        color = ramp(color_source, [( .22, dark), (.52, mid), (.8, light)], 'Material palette', -100, 300)
    links.new(color, shader.inputs['Base Color'])
    rough = ramp(noise.outputs['Fac'], [(.2, (lo,)*3), (.8, (hi,)*3)], 'Variable roughness', 0, 30)
    links.new(rough, shader.inputs['Roughness'])
    pores = node('ShaderNodeBump', 'Fine relief', 0, -240)
    pores.inputs['Strength'].default_value = .18
    pores.inputs['Distance'].default_value = .003 if role == 'glass' else .012
    links.new(fine.outputs['Fac'], pores.inputs['Height'])
    bump = node('ShaderNodeBump', 'Surface relief', 330, -160)
    bump.inputs['Strength'].default_value = .08 if role == 'glass' else .22
    bump.inputs['Distance'].default_value = .035 if role in {'stone', 'roof'} else .018
    links.new(height, bump.inputs['Height'])
    links.new(pores.outputs['Normal'], bump.inputs['Normal'])
    links.new(bump.outputs['Normal'], shader.inputs['Normal'])
    if role == 'metal':
        shader.inputs['Metallic'].default_value = 1
    if role == 'glass':
        # Decorative windows sit on opaque walls: dark reflective panes, not
        # transmissive glass that reveals the wall or environment behind them.
        shader.inputs['Transmission Weight'].default_value = 0
        shader.inputs['IOR'].default_value = 1.46
    mat.diffuse_color = (*mid, 1)
    return mat


def create_materials(seed=0):
    """Return eight materials; reuse matching seed/role without altering edits.

    A different seed creates a separate palette. Local coordinates are in object
    units, so object scale and orientation affect the appearance of textures.
    Stone courses are approximately 0.7 by 0.35 local units; on curved
    surfaces the projection changes at dominant-normal boundaries.
    """
    result = {}
    for role in _PALETTE:
        existing = next ( (m for m in bpy.data.materials if m.get(_TAG) == _version(role)
                          and m.get('EasyMidEvil.role') == role
                          and m.get('EasyMidEvil.seed') == str(seed)), None )
        result[role] = existing if existing is not None else _build(role, seed)
    return result
