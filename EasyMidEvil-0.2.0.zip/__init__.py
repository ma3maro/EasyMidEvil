bl_info = {
    'name': 'EasyMidEvil', 'author': 'EasyMidEvil', 'version': (0, 2, 0),
    'blender': (5, 3, 0), 'location': 'View3D > Sidebar > EasyMidEvil',
    'description': 'Create varied medieval building exteriors', 'category': 'Add Mesh',
}

import bpy
import secrets
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from . import geometry, materials, live
from mathutils import Vector

STYLES = (
    ('COTTAGE', 'Cottage', 'Timber-framed village cottage'),
    ('TAVERN', 'Tavern', 'A larger timber-framed inn'),
    ('BLACKSMITH', 'Blacksmith', 'Medieval smithy with workshop details'),
    ('TOWER', 'Tower', 'Fortified masonry tower'),
    ('KEEP', 'Castle Keep', 'Stone stronghold with battlements'),
)

def _selected_root(context):
    obj = context.active_object
    while obj:
        if obj.get('EasyMidEvil') and obj.get('building_type'):
            return obj
        obj = obj.parent
    return None


def _settings(context):
    root = _selected_root(context)
    return root.easymidevil if root and root.get(live.LIVE) else context.scene.easymidevil


def _updated(self, context):
    root = self.id_data
    if isinstance(root, bpy.types.Object) and root.get(live.LIVE):
        live.rebuild(root, context)


def _prepare(root, params):
    settings = root.easymidevil
    for name in ('style', 'width', 'depth', 'floors', 'seed', 'detail'):
        setattr(settings, name, params[name])
    root['EasyMidEvil'] = True
    root['building_type'] = params['style']
    root['variation'] = params['seed']
    root['_easymid_palette_seed'] = params['seed']
    live.mark_parts(root)
    root[live.LIVE] = True


class EASYMID_Settings(bpy.types.PropertyGroup):
    style: EnumProperty(name='Building', items=STYLES, default='COTTAGE', update=_updated)
    width: FloatProperty(name='Width', default=6.0, min=2.5, max=20, unit='LENGTH', update=_updated)
    depth: FloatProperty(name='Depth', default=5.0, min=2.5, max=20, unit='LENGTH', update=_updated)
    floors: IntProperty(name='Floors', default=2, min=1, max=3, update=_updated)
    seed: IntProperty(name='Variation', default=1, min=0, max=999999, description='Same number produces the same building details', update=_updated)
    detail: BoolProperty(name='Extra Details', default=True, description='Add architectural decoration', update=_updated)

class EASYMID_OT_variation(bpy.types.Operator):
    bl_idname = 'easymidevil.variation'
    bl_label = 'New Variation'
    bl_description = 'Choose a new variation number for the next building'
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        _settings(context).seed = secrets.randbelow(1000000)
        return {'FINISHED'}

class EASYMID_OT_create(bpy.types.Operator):
    bl_idname = 'easymidevil.create'
    bl_label = 'Create Building'
    bl_description = 'Add a new medieval building at the 3D cursor; existing objects are not replaced'
    bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'
    def execute(self, context):
        s = _settings(context)
        settings = dict(style=s.style, width=s.width, depth=s.depth, floors=s.floors, seed=s.seed, detail=s.detail)
        collection = bpy.data.collections.new('EasyMidEvil | ' + s.style.title())
        context.scene.collection.children.link(collection)
        try:
            mats = materials.create_materials(s.seed)
            root = geometry.build(settings, mats, collection)
            root.location = context.scene.cursor.location.copy()
            _prepare(root, settings)
        except Exception as exc:
            # Only remove the brand-new collection and objects created by this operation.
            for obj in list(collection.objects):
                data = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if data and data.users == 0 and isinstance(data, bpy.types.Mesh):
                    bpy.data.meshes.remove(data)
            bpy.data.collections.remove(collection)
            self.report({'ERROR'}, 'Could not create building: ' + str(exc))
            return {'CANCELLED'}
        for obj in context.selected_objects:
            obj.select_set(False)
        root.select_set(True)
        context.view_layer.objects.active = root
        self.report({'INFO'}, 'Building created at the 3D cursor')
        return {'FINISHED'}

class EASYMID_OT_copy_old(bpy.types.Operator):
    bl_idname = 'easymidevil.copy_old'
    bl_label = 'Create Editable Copy'
    bl_description = 'Create a new live-editable approximation next to the older building; keep the original unchanged'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        old = _selected_root(context)
        if not old or old.get(live.LIVE):
            self.report({'ERROR'}, 'Select a building created with an older version')
            return {'CANCELLED'}
        parts = [o for o in old.children if o.type == 'MESH']
        primary = next((o for o in parts if o.name.startswith('EasyMidEvil_plaster')), None)
        primary = primary or next((o for o in parts if o.name.startswith('EasyMidEvil_stone')), None)
        if not primary or not primary.data.vertices:
            self.report({'ERROR'}, 'Cannot estimate the older building dimensions')
            return {'CANCELLED'}
        coordinates = [primary.matrix_local @ v.co for v in primary.data.vertices]
        width = max(v.x for v in coordinates)-min(v.x for v in coordinates)
        depth = max(v.y for v in coordinates)-min(v.y for v in coordinates)
        scale = max(min(width, depth)/5, .01)
        height = max(v.z for v in coordinates)-min(v.z for v in coordinates)
        params = dict(style=old.get('building_type', 'COTTAGE'), width=max(2.5, min(20, width)),
                      depth=max(2.5, min(20, depth)), floors=max(1, min(3, round(height/(2.8*scale)))),
                      seed=max(0, min(999999, int(old.get('variation', 1)))), detail=True)
        col = bpy.data.collections.new('EasyMidEvil | Editable Copy')
        context.scene.collection.children.link(col)
        try:
            root = geometry.build(params, materials.create_materials(params['seed']), col)
            _prepare(root, params)
            root.matrix_world = old.matrix_world.copy()
            root.location += Vector((params['width'] + 2, 0, 0))
        except Exception as exc:
            live._discard_collection(col)
            self.report({'ERROR'}, 'Cannot make editable copy: ' + str(exc))
            return {'CANCELLED'}
        for obj in context.selected_objects:
            obj.select_set(False)
        root.select_set(True)
        context.view_layer.objects.active = root
        self.report({'INFO'}, 'Editable approximation created beside the untouched original')
        return {'FINISHED'}


class EASYMID_OT_village(bpy.types.Operator):
    bl_idname = 'easymidevil.village'
    bl_label = 'Create Starter Village'
    bl_description = 'Add five different medieval buildings as one movable group at the 3D cursor'
    bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'
    def execute(self, context):
        s = context.scene.easymidevil
        collection = bpy.data.collections.new('EasyMidEvil | Starter Village')
        context.scene.collection.children.link(collection)
        try:
            mats = materials.create_materials(s.seed)
            village = bpy.data.objects.new('EasyMidEvil Village', None)
            collection.objects.link(village)
            village.empty_display_type = 'CIRCLE'
            village.location = context.scene.cursor.location.copy()
            village['EasyMidEvil'] = True
            gap_x, gap_y = s.width * 1.9, s.depth * 2.2
            positions = ((-gap_x, 0), (0, 0), (gap_x, 0), (-gap_x*.6, gap_y), (gap_x*.6, gap_y))
            for i, ((style, _, _), (x, y)) in enumerate(zip(STYLES, positions)):
                params = dict(style=style, width=s.width, depth=s.depth, floors=s.floors,
                              seed=s.seed+i*101, detail=s.detail)
                house = geometry.build(params, mats, collection)
                house.parent = village
                house.location = (x, y, 0)
                _prepare(house, params)
        except Exception as exc:
            for obj in list(collection.objects):
                data = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)
                if data and data.users == 0 and isinstance(data, bpy.types.Mesh):
                    bpy.data.meshes.remove(data)
            bpy.data.collections.remove(collection)
            self.report({'ERROR'}, 'Could not create village: ' + str(exc))
            return {'CANCELLED'}
        for obj in context.selected_objects:
            obj.select_set(False)
        village.select_set(True)
        context.view_layer.objects.active = village
        self.report({'INFO'}, 'Starter village created at the 3D cursor')
        return {'FINISHED'}

class EASYMID_PT_panel(bpy.types.Panel):
    bl_label = 'EasyMidEvil'
    bl_idname = 'EASYMID_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'EasyMidEvil'
    def draw(self, context):
        layout = self.layout
        root = _selected_root(context)
        s = _settings(context)
        if root and root.get(live.LIVE):
            layout.label(text='Editing selected building', icon='OUTLINER_OB_EMPTY')
        elif root:
            layout.label(text='Older building: create an editable copy', icon='INFO')
            layout.operator('easymidevil.copy_old', icon='DUPLICATE')
        else:
            layout.label(text='Create a medieval building', icon='HOME')
        controls = layout.column(align=True)
        controls.enabled = context.mode == 'OBJECT'
        controls.prop(s, 'style')
        controls.prop(s, 'floors')
        controls.prop(s, 'width')
        if s.style != 'TOWER':
            controls.prop(s, 'depth')
        else:
            controls.prop(s, 'depth', text='Diameter Limit')
        controls.prop(s, 'detail')
        layout.separator()
        row = controls.row(align=True)
        row.prop(s, 'seed')
        row.operator('easymidevil.variation', text='', icon='FILE_REFRESH')
        if root and root.get(live.LIVE):
            layout.label(text='Changes update this building live', icon='FILE_REFRESH')
            if root.get('_easymid_error'):
                layout.label(text='Update failed; see system console', icon='ERROR')
        else:
            layout.label(text='New buildings appear at the 3D cursor', icon='PIVOT_CURSOR')
        layout.operator('easymidevil.create', icon='ADD')
        layout.operator('easymidevil.village', icon='OUTLINER_COLLECTION')
        layout.label(text='Exteriors only; doors are decorative', icon='INFO')

_CLASSES = (EASYMID_Settings, EASYMID_OT_variation, EASYMID_OT_create, EASYMID_OT_copy_old, EASYMID_OT_village, EASYMID_PT_panel)

def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.easymidevil = PointerProperty(type=EASYMID_Settings)
    bpy.types.Object.easymidevil = PointerProperty(type=EASYMID_Settings)

def unregister():
    del bpy.types.Object.easymidevil
    del bpy.types.Scene.easymidevil
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
